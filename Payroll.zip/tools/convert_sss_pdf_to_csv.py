"""Convert SSS Contribution Table PDF into CSV rows.
Requirements:
  - Java (tabula requires it)
  - pip install tabula-py pandas
Usage:
  python tools/convert_sss_pdf_to_csv.py /path/to/2025-SSS-Contribution-Table-rev.pdf data/sss_msc.csv

Notes:
- Tabula works best when the PDF has clearly structured tables. If output looks wrong, try adjusting pages or area parameter.
- If tabula-py fails, try using Camelot (pip install camelot-py[cv]) or manual extraction.
"""
import sys, os
import tabula
import pandas as pd

def convert(pdf_path, out_csv):
    if not os.path.exists(pdf_path):
        raise SystemExit('PDF not found: ' + pdf_path)
    # try reading all tables
    print('Reading tables from PDF...')
    tables = tabula.read_pdf(pdf_path, pages='all', multiple_tables=True, lattice=True)
    print(f'Found {len(tables)} table(s).')
    # heuristic: pick largest table by rows that contains 'salary' or 'msc'
    candidate = None
    for t in tables:
        cols = [c.lower() for c in t.columns.astype(str)]
        if any('msc' in c or 'salary' in c or 'range' in c for c in cols):
            candidate = t
            break
    if candidate is None:
        candidate = tables[0]
    # normalize columns: try to find salary_from, salary_to, msc, ee, er
    df = candidate.copy()
    # drop all-empty cols
    df = df.loc[:, (df != df.iloc[0]).any()]
    # attempt to parse by content
    # This part may need manual mapping depending on PDF structure.
    print('Sample columns:', df.columns.tolist())
    # Save raw extracted table for inspection
    raw_path = out_csv.replace('.csv', '.raw.csv')
    df.to_csv(raw_path, index=False)
    print('Saved raw extracted table to', raw_path)
    # If the PDF uses 3 columns like 'Range' | 'MSC' | 'Total' adjust accordingly.
    # User should inspect raw CSV and map columns manually if needed.
    df.to_csv(out_csv, index=False)
    print('Wrote CSV to', out_csv)

if __name__ == '__main__':
    if len(sys.argv) < 3:
        print('Usage: python convert_sss_pdf_to_csv.py /path/to/SSS.pdf out.csv')
        sys.exit(1)
    convert(sys.argv[1], sys.argv[2])
