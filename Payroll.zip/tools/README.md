Conversion & Build Tools

1) Converting SSS PDF to CSV
- Install Java and pip packages: `pip install tabula-py pandas`
- Run: `python tools/convert_sss_pdf_to_csv.py /path/to/2025-SSS-Contribution-Table-rev.pdf data/sss_msc.csv`
- Inspect data/sss_msc.raw.csv and map columns if needed; clean up and ensure headers: salary_from,salary_to,msc,ee,er

2) Xendit payouts integration (sample)
- Set env: XENDIT_SECRET_KEY in server/.env
- Use server/src/services/payouts_xendit_integration.processSinglePayout(payrollItem, payeeBank) to send disbursement
- Confirm webhook events per Xendit docs and wire to /webhooks/payouts

3) Building Electron installer via GitHub Actions
- Push repo to GitHub.
- Add Repository secrets: XENDIT_SECRET_KEY, other provider keys if used.
- The workflow `.github/workflows/ci-electron.yml` will run server tests and produce a Windows installer artifact.

