/*
Xendit Payout Adapter (sample)
- Uses Xendit Payouts API to create payouts to bank accounts or e-wallets.
- Requires: XENDIT_SECRET_KEY in env
Docs: https://docs.xendit.co/docs/payouts-via-api
*/
const axios = require('axios');
const endpoint = 'https://api.xendit.co/v2/disbursements'; // example; check docs for exact endpoints
const apiKey = process.env.XENDIT_SECRET_KEY;

async function createDisbursement({ externalId, amount, bankCode, accountHolderName, accountNumber, description }) {
  if (!apiKey) throw new Error('XENDIT_SECRET_KEY missing');
  const auth = { username: apiKey, password: '' };
  const payload = { external_id: externalId, amount, bank_code: bankCode, account_holder_name: accountHolderName, account_number: accountNumber, description };
  const res = await axios.post(endpoint, payload, { auth });
  return res.data;
}

module.exports = { createDisbursement };
