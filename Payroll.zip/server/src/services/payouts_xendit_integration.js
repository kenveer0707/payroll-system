const xendit = require('./payout_provider_xendit');
const fs = require('fs');
const path = require('path');
const payoutsDb = path.join(__dirname, '../../data/payouts.json');

function loadState() {
  if (!fs.existsSync(payoutsDb)) return { batches: [], payouts: [] };
  return JSON.parse(fs.readFileSync(payoutsDb));
}
function saveState(s) { fs.writeFileSync(payoutsDb, JSON.stringify(s, null, 2)); }

async function processSinglePayout(payrollItem, payeeBank) {
  // payrollItem: { id, amount, employee details }
  // payeeBank: { bankCode, accountNumber, accountName }
  const amount = payrollItem.amount;
  const externalId = 'payroll_' + payrollItem.id + '_' + Date.now();
  try {
    const resp = await xendit.createDisbursement({ externalId, amount, bankCode: payeeBank.bankCode, accountHolderName: payeeBank.accountName, accountNumber: payeeBank.accountNumber, description: 'Payroll payout' });
    return { status: 'submitted', providerRef: resp.id || resp.reference_id, raw: resp };
  } catch (e) {
    return { status: 'failed', error: e.message };
  }
}

module.exports = { processSinglePayout };
